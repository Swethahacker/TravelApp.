package com.brikmas.travelapp

import androidx.compose.runtime.Composable

@Composable
internal fun AppViewiOS() {
    CommonView()
}